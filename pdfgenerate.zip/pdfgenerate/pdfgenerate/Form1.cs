﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using iText.IO.Image;
using iText.Kernel.Colors;
using iText.Kernel.Pdf;
using iText.Kernel.Pdf.Action;
using iText.Kernel.Pdf.Canvas.Draw;
using iText.Layout;
using iText.Layout.Element;
using iText.Layout.Properties;

namespace pdfgenerate
{
    public partial class Form1 : Form
    {
        string[] states = { "State", "New York", "New Jersey", "California" };
        string[] capital = { "Capital", "Albany", "Trenton", "Sacramento" };
        public Form1()
        {
            InitializeComponent();
        }

        private void Form1_Load(object sender, EventArgs e)
        {
            PdfWriter writer = new PdfWriter("C:\\samplepdf\\demo.pdf");
            PdfDocument pdf = new PdfDocument(writer);
            Document document = new Document(pdf);
            Paragraph header = new Paragraph("Here is sample")
                .SetTextAlignment(TextAlignment.CENTER).SetFontSize(20);
            document.Add(header);
            Paragraph subheader = new Paragraph("Thank you for using it core soft")
                .SetTextAlignment(TextAlignment.CENTER).SetFontSize(15);
            document.Add(subheader);
            LineSeparator ls = new LineSeparator(new SolidLine());
            document.Add(ls);
            Paragraph newline = new Paragraph(new Text("\n"));
            Paragraph paragraph = new Paragraph("Please like and comment on the video. And subscribe the channel")
                .SetTextAlignment(TextAlignment.LEFT).SetFontSize(12);
            document.Add(paragraph);
            Table table = new Table(2/*number of columns in the table*/, false);
            table.SetHorizontalAlignment(iText.Layout.Properties.HorizontalAlignment.CENTER);
            int i = 0;
            foreach(string state in states)
            {
                Cell cell11 = new Cell(1, 1)
                    .SetBackgroundColor(ColorConstants.GRAY)
                    .SetTextAlignment(TextAlignment.CENTER).Add(new Paragraph(state));
                Cell cell21 = new Cell(1, 1)
                    .SetBackgroundColor(ColorConstants.GRAY)
                    .SetTextAlignment(TextAlignment.CENTER).Add(new Paragraph(capital[i]));
                i = i + 1;
                table.AddCell(cell11);
                table.AddCell(cell21);
            }
            document.Add(table);
            iText.Layout.Element.Image img = new iText.Layout.Element.Image(ImageDataFactory
                .Create(@"C:\\samplepdf\\image.png"))
                .SetHorizontalAlignment(iText.Layout.Properties.HorizontalAlignment.CENTER);
            document.Add(img);
            Link link = new Link("click here",
                PdfAction.CreateURI("https://www.youtube.com/channel/UCQL_ffEP42Pxh7BrYVrSxWw"));
            Paragraph hyperlink = new Paragraph("Please").Add(link.SetBold().SetUnderline()
                .SetItalic().SetFontColor(ColorConstants.BLUE)).Add(" to go to channel,");
            document.Add(newline);
            document.Add(hyperlink);
            document.Close();
        }
    }
}
